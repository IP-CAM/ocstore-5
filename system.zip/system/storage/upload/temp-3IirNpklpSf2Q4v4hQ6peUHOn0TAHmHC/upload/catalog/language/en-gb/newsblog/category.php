<?php
// Text
$_['text_refine'] 		= 'Select a sub-category';
$_['text_attributes'] 	= 'Custom fields';
$_['text_error'] 		= 'Category is not found!';
$_['text_empty'] 		= 'In this category there are no materials.';
